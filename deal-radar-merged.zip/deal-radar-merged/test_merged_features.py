"""Tests for the pieces merged in from Deal Radar 4: live feed, Finnhub news, headline caps, portfolio data helpers."""
import asyncio
import json
import threading
import time
from datetime import date, datetime, timedelta, timezone

import pytest

import live
import market
import news


def _headline(title, days_ago=0.0):
    return {"title": title, "link": "", "source": "test",
            "published": datetime.now(timezone.utc) - timedelta(days=days_ago)}


def test_news_decisive_headline_lifts_the_cap():
    plain = news.score([_headline("FTC sues to block Halcyon deal for Marrow")] * 3, ["Marrow"])
    assert abs(plain["adjustment"]) <= news.CAP + 1e-9
    ended = news.score([_headline("Halcyon terminates the merger agreement with Marrow Therapeutics")] * 3, ["Marrow"])
    assert ended["flags"]["ended"] and ended["adjustment"] < -news.CAP
    assert ended["adjustment"] >= -news.CAP_DECISIVE


def test_news_merges_finnhub_and_dedupes(monkeypatch):
    monkeypatch.setattr(news, "fetch", lambda t: [_headline("Marrow shareholders approve merger")])
    monkeypatch.setattr(news, "finnhub_items", lambda t, k: [_headline("Marrow shareholders approve merger"), _headline("FTC issues second request on Marrow deal")])
    out = news.for_ticker("MARR", ["Marrow"], "KEY")
    assert out["sources"] == ["Yahoo Finance", "Finnhub"]
    assert len(out["items"]) == 2


def test_news_survives_one_failing_source(monkeypatch):
    def boom(t):
        raise news.NewsError("Yahoo down")
    monkeypatch.setattr(news, "fetch", boom)
    monkeypatch.setattr(news, "finnhub_items", lambda t, k: [_headline("Marrow shareholders approve merger")])
    assert news.for_ticker("MARR", ["Marrow"], "KEY")["sources"] == ["Finnhub"]
    with pytest.raises(news.NewsError):
        news.for_ticker("MARR", ["Marrow"], "")


def test_news_config_is_what_the_page_embeds():
    cfg = news.config()
    assert cfg["capDecisive"] == news.CAP_DECISIVE and len(cfg["rules"]) == len(news.RULES)
    json.dumps(cfg)


def test_live_yahoo_quote_parsing_and_unknown_symbol():
    f = live.Feed("", yahoo=True)
    f._get_json = lambda url, headers=None, timeout=10: {"chart": {"result": [{"meta": {"regularMarketPrice": 12.34, "chartPreviousClose": 12.0, "regularMarketTime": 1790000000}}]}}
    assert f._yahoo_quote("X") == (12.34, 12.0, 1790000000)
    f._get_json = lambda *a, **k: {"chart": {"result": None}}
    assert f._yahoo_quote("NOPE") is None
    assert f.source == "yahoo" and live.Feed("k").source == "finnhub" and live.Feed("", yahoo=False).source is None


def test_live_older_poll_does_not_overwrite_newer_trade():
    f = live.Feed("k")
    f._update("AAA", 50.0, None, time.time(), src="finnhub-ws", trade=True)
    f._update("AAA", 49.0, 48.0, time.time() - 60, src="finnhub")      # polled quote older than the trade
    assert f.px["AAA"]["p"] == 50.0 and f.px["AAA"]["pc"] == 48.0


def test_live_unknown_symbol_is_not_a_feed_error():
    f = live.Feed("k")
    f._finnhub_quote = lambda sym: None
    f._poll_one("ZZZ")
    assert f.error is None and f.status()["unknown"] == [] and "ZZZ" in f.unknown   # status lists it only while watched
    f.watch(["ZZZ"])
    assert f.status()["unknown"] == ["ZZZ"]


def test_market_hours():
    ny = live.NY
    if ny is None:
        pytest.skip("no tz database")
    assert live.market_open(datetime(2026, 11, 10, 10, 0, tzinfo=ny))
    assert not live.market_open(datetime(2026, 11, 10, 17, 0, tzinfo=ny))
    assert not live.market_open(datetime(2026, 11, 8, 11, 0, tzinfo=ny))     # a Sunday


def test_websocket_client_and_feed_against_a_local_server():
    websockets = pytest.importorskip("websockets")
    subs, port_box = [], {}

    async def handler(ws):
        async def send():
            while True:
                await asyncio.sleep(0.1)
                for s in list(subs):
                    await ws.send(json.dumps({"type": "trade", "data": [{"p": 51.5, "s": s, "t": int(time.time() * 1000), "v": 1}]}))
        task = asyncio.ensure_future(send())
        try:
            async for m in ws:
                d = json.loads(m)
                if d["type"] == "subscribe":
                    subs.append(d["symbol"])
        finally:
            task.cancel()

    def serve():
        async def main():
            async with websockets.serve(handler, "127.0.0.1", 0, ping_interval=None) as srv:
                port_box["port"] = srv.sockets[0].getsockname()[1]
                await asyncio.Future()
        asyncio.run(main())
    threading.Thread(target=serve, daemon=True).start()
    for _ in range(50):
        if "port" in port_box:
            break
        time.sleep(0.1)
    f = live.Feed("KEY", ws_url="ws://127.0.0.1:%d" % port_box["port"], rest_base="http://127.0.0.1:1")
    f._poll_loop = lambda: None            # only the WebSocket path is under test
    f.start()
    q = f.subscribe()
    f.watch(["AAA"])
    got = None
    deadline = time.time() + 8
    while time.time() < deadline and got is None:
        try:
            got = q.get(timeout=0.5)["prices"].get("AAA")
        except Exception:
            pass
    assert got and got["p"] == 51.5 and got["src"] == "finnhub-ws"
    assert f.status()["ws"]["connected"]


def test_beta_vs_recovers_a_known_beta():
    import random
    rng = random.Random(1)
    days = [date(2024, 1, 1) + timedelta(days=i) for i in range(300)]
    mk, st, pm, ps = [], [], 100.0, 50.0
    for _ in days:
        r = rng.gauss(0, 0.01)
        pm *= 1 + r
        ps *= 1 + 1.4 * r + rng.gauss(0, 0.002)
        mk.append(pm)
        st.append(ps)
    beta = market.beta_vs(list(zip(days, st)), dict(zip(days, mk)))
    assert 1.3 < beta < 1.5
    assert market.beta_vs(list(zip(days[:30], st[:30])), dict(zip(days, mk))) is None


def test_history_many_aligns_dates_and_names_failures(monkeypatch):
    base = date(2025, 1, 1)
    full = [(base + timedelta(days=i), 100.0 + i) for i in range(120)]

    def fake(ticker, start, end, timeout=15):
        if ticker == "BAD":
            raise market.MarketError("no listing")
        return full[5:] if ticker == "AAA" else full
    monkeypatch.setattr(market, "history", fake)
    out = market.history_many(["AAA", "BAD"], days=100)
    assert "BAD" in out["errors"] and set(out["closes"]) == {"SPY", "AAA"}
    assert len(out["dates"]) == len(out["closes"]["AAA"]) == len(out["closes"]["SPY"]) == 100
